package com.example.sunny_pc.chackbox;

import android.content.SharedPreferences;
import android.net.LocalSocketAddress;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

import static com.example.sunny_pc.chackbox.customadpter.Name;

public class displayprofile extends AppCompatActivity {
    TextView txtname,txtemail,txtadd,txtmob;
    public static ArrayList<Model> modelArrayList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_displayprofile);
        txtname=(TextView)findViewById(R.id.name);
        txtemail=(TextView)findViewById(R.id.email);
        txtadd=(TextView)findViewById(R.id.add);
        txtmob=(TextView)findViewById(R.id.mob);
        txtname.setEnabled(false);
        txtemail.setEnabled(false);
        txtadd.setEnabled(false);
        txtmob.setEnabled(false);


         String string=getIntent().getStringExtra("animal");
        txtname.setText(string);
        txtemail.setText(string);
        txtadd.setText(string);
        txtmob.setText(string);

    }

}
