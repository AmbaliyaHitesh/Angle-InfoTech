package com.example.sunny_pc.chackbox;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class customadpter extends BaseAdapter {


    int globalInc = 0;
    private Context context;
    public static ArrayList<Model> modelArrayList;

    public static final String Name = "emailKey";

    public customadpter(Context context, ArrayList<Model> modelArrayList) {

        this.context = context;
        this.modelArrayList = modelArrayList;

    }

    @Override
    public int getCount() {
        return modelArrayList.size();
    }

    public int getItemViewType(int i) {

        return i;
    }

    @Override
    public Object getItem(int i) {
        return modelArrayList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        final ViewHolder holder;

        if (view == null) {
            holder = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.activity_iv_item, null, true);


            holder.checkBox = (CheckBox) view.findViewById(R.id.cb);
            holder.tvAnimal = (TextView) view.findViewById(R.id.animal);


            view.setTag(holder);
            holder.checkBox.setTag(modelArrayList);
            holder.tvAnimal.setText(modelArrayList.get(i).getAnimal());
            holder.checkBox.setChecked(modelArrayList.get(i).getSelected());


        } else {
            // the getTag returns the viewHolder object set as a tag to the view
            holder = (ViewHolder) view.getTag();
        }


       holder.checkBox.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               if (globalInc >= 5) {

                   // String yourVote = holder.checkBox.getText().toString();
                   Toast.makeText(context, "Error = " + globalInc, Toast.LENGTH_LONG).show();
                   holder.checkBox .setChecked(false);
                   globalInc--;
                   // intent.putExtra("animal",yourVote);


               } else {
                   Intent intent=new Intent(context,displayprofile.class);
                   context.startActivity(intent);
                   // c.setSelected(b);
               }

           }
       });

        return view;
    }

    private class ViewHolder {

        CheckBox checkBox;
        TextView tvAnimal;

    }

}
