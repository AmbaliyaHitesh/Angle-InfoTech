package com.example.sunny_pc.chackbox;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    private ArrayList<Model> modelArrayList = new ArrayList<Model>();
    private customadpter customAdapter;
    String result;
    private String[] animallist = new String[]{"Lion", "Tiger", "Leopard", "Cat", "Hitesh", "Henish"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView) findViewById(R.id.listView1);
        modelArrayList = getModel(false);
        customAdapter = new customadpter(this, modelArrayList);
        listView.setAdapter(customAdapter);






    }

    private ArrayList<Model> getModel(boolean isSelect) {
        ArrayList<Model> list = new ArrayList<>();
        for (int i = 0; i < 6; i++) {

            Model model = new Model();
            model.setSelected(isSelect);
            model.setAnimal(animallist[i]);
            list.add(model);
        }
        return list;

    }
}